<?php
	header('Content-type: application/json');
	session_start();
	require_once '..\classes\User.php';
	require_once '..\classes\LocalStorage.php';
	require_once '..\classes\CONFIG.php';
	
	use classes\User;
	use classes\LocalStorage;
	use classes\CONFIG;
	
	$json = file_get_contents('php://input');
	$obj = json_decode($json, true);
	$data = userProcessor ($obj["operation"], $obj["data"]);
	echo (json_encode($data));
	function userProcessor (string $operation, mixed $postData) {
		// initilizing the ajax response
		$successState = false;
		$user = new User();
		switch ($operation) {
			case "add_user":
				$successState = $user->addUser($postData);
				break;
			case "get_user":
				$successState = $user->getUser($postData);
				break;
			
			case "find_user":
				$successState = $user->findUser($postData);
				break;
			
			case "delete_user":
				$successState = $user->deleteUser($postData);
				break;
			
			case "delete_all":
				$successState = (new LocalStorage())->drop(CONFIG::USERS);
				break;
		}
		
		return $successState;
	}
?>