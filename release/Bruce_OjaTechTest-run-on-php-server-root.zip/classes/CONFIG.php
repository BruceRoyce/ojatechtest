<?php
	namespace classes;
	abstract class CONFIG {
		const USERS = "ojaUsers";
	}